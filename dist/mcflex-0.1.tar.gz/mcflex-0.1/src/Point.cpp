#include "Point.hpp"

// Point::Point(unsigned int d){
// 	dim = d;
// }

// Point::~Point(){

// }