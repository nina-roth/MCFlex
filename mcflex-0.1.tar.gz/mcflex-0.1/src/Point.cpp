#include "Point.hpp"

// template<typename T>
// void Point<T>::set_dummy(T dummy_){
// 	dummy = dummy_;

// }

// template class Point<double>;
// template class Point<float>;